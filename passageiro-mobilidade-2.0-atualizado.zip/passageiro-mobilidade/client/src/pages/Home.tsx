import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Map as MapboxMapInstance } from "mapbox-gl";
import type { User } from "firebase/auth";
import {
  ArrowRight,
  Crosshair,
  LocateFixed,
  Loader2,
  LogOut,
  MapPin,
  Navigation,
  Pencil,
  Search,
  ShieldCheck,
  Sparkles,
  UserRound,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MapboxMap } from "@/components/MapboxMap";
import { cancelRideRequest, createRideRequest, firebaseAuth, friendlyAuthError, observeRide } from "@/lib/firebase";

const FALLBACK_CENTER = { lat: -23.55052, lng: -46.633308 };
const SEARCH_RADIUS_KM = 100;
const PRICING = {
  baseFare: 5,
  perKm: 2.2,
} as const;

type Coordinates = { lat: number; lng: number; accuracy?: number };
type Suggestion = {
  id: string;
  mapboxId?: string;
  label: string;
  shortLabel: string;
  lat: number;
  lng: number;
  type?: string;
};

function distanceKm(a: Coordinates, b: Coordinates) {
  const earthRadius = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLng * sinLng;
  return 2 * earthRadius * Math.asin(Math.sqrt(h));
}

function extractStreetNumber(address: Record<string, string | undefined>) {
  return address.house_number ? `, ${address.house_number}` : "";
}

function compactLabel(displayName: string, address: Record<string, string | undefined>) {
  const road = address.road || address.pedestrian || address.path || displayName.split(",")[0];
  const city = address.city || address.town || address.municipality || address.village;
  return `${road}${extractStreetNumber(address)}${city ? ` · ${city}` : ""}`;
}

function cleanSuggestions(items: Suggestion[], origin: Coordinates) {
  const unique = new Map<string, Suggestion>();
  items.forEach((item) => {
    const key = item.shortLabel.toLocaleLowerCase("pt-BR").replace(/\s+/g, " ").trim();
    if (!unique.has(key)) unique.set(key, item);
  });
  return Array.from(unique.values()).sort((a, b) => distanceKm(origin, a) - distanceKm(origin, b)).slice(0, 8);
}

async function fetchStreetSuggestions(value: string, origin: Coordinates, sessionToken: string) {
  const token = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN as string | undefined;
  if (!token) throw new Error("mapbox_token_missing");
  const params = new URLSearchParams({ q: value.trim(), access_token: token, proximity: `${origin.lng},${origin.lat}`, country: "BR", language: "pt", limit: "8", session_token: sessionToken });
  const response = await fetch(`https://api.mapbox.com/search/searchbox/v1/suggest?${params.toString()}`, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error("search_failed");
  const data = await response.json() as { suggestions?: Array<{ name?: string; mapbox_id: string; place_formatted?: string; feature_type?: string }> };
  return (data.suggestions ?? []).map((item) => {
    const label = [item.name, item.place_formatted].filter(Boolean).join(" · ");
    return { id: item.mapbox_id, mapboxId: item.mapbox_id, label, shortLabel: label, lat: origin.lat, lng: origin.lng, type: item.feature_type || "endereço" };
  });
}

async function retrieveMapboxSuggestion(suggestion: Suggestion, sessionToken: string) {
  const token = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN as string | undefined;
  if (!token || !suggestion.mapboxId) return suggestion;
  const response = await fetch(`https://api.mapbox.com/search/searchbox/v1/retrieve/${encodeURIComponent(suggestion.mapboxId)}?session_token=${encodeURIComponent(sessionToken)}&access_token=${encodeURIComponent(token)}`, { headers: { Accept: "application/geo+json" } });
  if (!response.ok) throw new Error("retrieve_failed");
  const data = await response.json() as { features?: Array<{ geometry?: { coordinates?: [number, number] }; properties?: { full_address?: string; name?: string; place_formatted?: string } }> };
  const feature = data.features?.[0];
  const coordinates = feature?.geometry?.coordinates;
  if (!coordinates) return suggestion;
  const properties = feature.properties ?? {};
  const label = properties.full_address || [properties.name, properties.place_formatted].filter(Boolean).join(" · ") || suggestion.label;
  return { ...suggestion, label, shortLabel: label, lng: coordinates[0], lat: coordinates[1] };
}

function AuthPanel({ onClose }: { onClose: () => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!email || !password) {
      toast.error("Preencha e-mail e senha.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "login") await firebaseAuth.signInEmail(email, password);
      else await firebaseAuth.createEmail(email, password);
      toast.success(mode === "login" ? "Bem-vindo de volta." : "Conta criada com sucesso.");
      onClose();
    } catch (error) {
      toast.error(friendlyAuthError(error));
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setBusy(true);
    try {
      await firebaseAuth.signInGoogle();
      toast.success("Login com Google concluído.");
      onClose();
    } catch (error) {
      toast.error(friendlyAuthError(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[2000] grid place-items-center bg-slate-950/45 p-4 backdrop-blur-sm">
      <Card className="max-h-[calc(100vh-2rem)] w-full max-w-md overflow-y-auto border-white/70 bg-white/95 shadow-2xl shadow-slate-900/20">
        <CardContent className="p-6 sm:p-8">
          <div className="mb-7 flex items-start justify-between gap-4">
            <div>
              <Badge className="mb-3 border-emerald-200 bg-emerald-50 text-emerald-700">Firebase Auth</Badge>
              <h2 className="font-display text-3xl font-black tracking-tight text-slate-950">
                {mode === "login" ? "Entre para continuar" : "Crie seu acesso"}
              </h2>
              <p className="mt-2 text-sm leading-6 text-slate-500">Seu mapa e seus endereços ficam prontos para a próxima corrida.</p>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} aria-label="Fechar login"><X className="h-5 w-5" /></Button>
          </div>
          <form className="space-y-4" onSubmit={submit}>
            <div>
              <label className="mb-2 block text-xs font-bold uppercase tracking-[0.18em] text-slate-500">E-mail</label>
              <Input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="voce@email.com" autoComplete="email" />
            </div>
            <div>
              <label className="mb-2 block text-xs font-bold uppercase tracking-[0.18em] text-slate-500">Senha</label>
              <Input value={password} onChange={(event) => setPassword(event.target.value)} type="password" placeholder="Mínimo de 6 caracteres" autoComplete={mode === "login" ? "current-password" : "new-password"} />
            </div>
            <Button className="h-12 w-full bg-slate-950 text-white hover:bg-slate-800" disabled={busy} type="submit">
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {mode === "login" ? "Entrar" : "Criar conta"}
              <ArrowRight className="ml-auto h-4 w-4" />
            </Button>
          </form>
          <div className="my-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.18em] text-slate-400"><span className="h-px flex-1 bg-slate-200" />ou<span className="h-px flex-1 bg-slate-200" /></div>
          <Button variant="outline" className="h-12 w-full border-slate-200" disabled={busy} onClick={google}><span className="mr-3 grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-blue-500 via-red-500 to-yellow-400 text-xs font-black text-white">G</span>Continuar com Google</Button>
          <button className="mx-auto mt-5 block text-sm font-semibold text-emerald-700 hover:text-emerald-900" onClick={() => setMode(mode === "login" ? "signup" : "login")}>
            {mode === "login" ? "Ainda não tenho conta" : "Já tenho uma conta"}
          </button>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [coords, setCoords] = useState<Coordinates | null>(null);
  const [gpsLoading, setGpsLoading] = useState(true);
  const [gpsMessage, setGpsMessage] = useState("Buscando sua localização...");
  const [map, setMap] = useState<MapboxMapInstance | null>(null);
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [searching, setSearching] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState<Suggestion | null>(null);
  const [houseNumber, setHouseNumber] = useState("");
  const [complement, setComplement] = useState("");
  const [locationLabel, setLocationLabel] = useState("Escolha o ponto de embarque");
  const [pickupMode, setPickupMode] = useState(false);
  const [pickupQuery, setPickupQuery] = useState("");
  const [pickupSuggestions, setPickupSuggestions] = useState<Suggestion[]>([]);
  const [pickupSearching, setPickupSearching] = useState(false);
  const [pickupLocation, setPickupLocation] = useState<Suggestion | null>(null);
  const [pickupHouseNumber, setPickupHouseNumber] = useState("");
  const [pickupComplement, setPickupComplement] = useState("");
  const [pickupDetailsOpen, setPickupDetailsOpen] = useState(false);
  const [destinationDetailsOpen, setDestinationDetailsOpen] = useState(false);
  const [routeInfo, setRouteInfo] = useState<{ distanceMeters: number; durationSeconds: number } | null>(null);
  const [requestState, setRequestState] = useState<"idle" | "saving" | "searching">("idle");
  const [rideId, setRideId] = useState<string | null>(null);
  const [activeRide, setActiveRide] = useState<Record<string, unknown> | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const searchTimeout = useRef<number | undefined>(undefined);
  const pickupSearchTimeout = useRef<number | undefined>(undefined);
  const searchSessionToken = useRef(crypto.randomUUID());

  useEffect(() => firebaseAuth.observe(setUser), []);

  useEffect(() => {
    if (!rideId) return;
    return observeRide(rideId, (ride) => {
      setActiveRide(ride);
      if (ride?.status === "cancelled") setRequestState("idle");
    }, () => toast.error("Não foi possível acompanhar o status da corrida."));
  }, [rideId]);

  const updateLocation = useCallback((position: GeolocationPosition) => {
    const next = { lat: position.coords.latitude, lng: position.coords.longitude, accuracy: position.coords.accuracy };
    setCoords(next);
    setGpsLoading(false);
    setGpsMessage(position.coords.accuracy < 80 ? "Localização precisa ativada" : "Localização aproximada ativada");
    void fetch(`https://nominatim.openstreetmap.org/reverse?lat=${next.lat}&lon=${next.lng}&format=jsonv2&addressdetails=1`, { headers: { Accept: "application/json", "Accept-Language": "pt-BR" } })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error("reverse_failed")))
      .then((data: { display_name?: string; address?: Record<string, string | undefined> }) => {
        const address = data.address ?? {};
        setLocationLabel(compactLabel(data.display_name ?? "Sua localização", address));
      })
      .catch(() => setLocationLabel("Localização atual"));
  }, []);

  const requestLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setGpsLoading(false);
      setGpsMessage("Seu navegador não oferece geolocalização.");
      return;
    }
    setGpsLoading(true);
    setGpsMessage("Buscando sua localização...");
    navigator.geolocation.getCurrentPosition(updateLocation, () => {
      setGpsLoading(false);
      setGpsMessage("Não foi possível acessar o GPS. Confira a permissão do navegador.");
      toast.error("Permita a localização para encontrar endereços perto de você.");
    }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 });
  }, [updateLocation]);

  useEffect(() => {
    requestLocation();
    if (!navigator.geolocation) return;
    const watcher = navigator.geolocation.watchPosition(updateLocation, () => undefined, { enableHighAccuracy: true, maximumAge: 15000, timeout: 20000 });
    return () => navigator.geolocation.clearWatch(watcher);
  }, [requestLocation, updateLocation]);

  const center = coords ?? FALLBACK_CENTER;

  const searchAddresses = useCallback(async (value: string) => {
    if (value.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    setSearching(true);
    try {
      setSuggestions(await fetchStreetSuggestions(value, center, searchSessionToken.current));
    } catch {
      setSuggestions([]);
      toast.error("Não foi possível buscar endereços agora.");
    } finally {
      setSearching(false);
    }
  }, [center]);

  const searchPickupAddresses = useCallback(async (value: string) => {
    if (value.trim().length < 2) {
      setPickupSuggestions([]);
      return;
    }
    setPickupSearching(true);
    try {
      setPickupSuggestions(await fetchStreetSuggestions(value, center, searchSessionToken.current));
    } catch {
      setPickupSuggestions([]);
      toast.error("Não foi possível buscar esse local agora.");
    } finally {
      setPickupSearching(false);
    }
  }, [center]);

  useEffect(() => {
    window.clearTimeout(searchTimeout.current);
    if (selectedAddress || query.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    searchTimeout.current = window.setTimeout(() => void searchAddresses(query), 120);
    return () => window.clearTimeout(searchTimeout.current);
  }, [query, searchAddresses, selectedAddress]);

  useEffect(() => {
    window.clearTimeout(pickupSearchTimeout.current);
    if (!pickupMode || pickupQuery.trim().length < 2) {
      setPickupSuggestions([]);
      return;
    }
    pickupSearchTimeout.current = window.setTimeout(() => void searchPickupAddresses(pickupQuery), 120);
    return () => window.clearTimeout(pickupSearchTimeout.current);
  }, [pickupMode, pickupQuery, searchPickupAddresses]);

  const selectSuggestion = async (suggestion: Suggestion) => {
    setSearching(true);
    try {
      const detailed = await retrieveMapboxSuggestion(suggestion, searchSessionToken.current);
      setSelectedAddress(detailed);
      setQuery(detailed.shortLabel);
      setDestinationDetailsOpen(true);
      if (map) {
        map.easeTo({ center: [detailed.lng, detailed.lat], duration: 400 });
        map.setZoom(16);
      }
    } catch {
      toast.error("Não foi possível confirmar este endereço.");
    } finally {
      setSearching(false);
    }
    setSuggestions([]);
  };

  const selectPickupSuggestion = async (suggestion: Suggestion) => {
    setPickupSearching(true);
    try {
      const detailed = await retrieveMapboxSuggestion(suggestion, searchSessionToken.current);
      setPickupLocation(detailed);
      setPickupQuery(detailed.shortLabel);
      setPickupDetailsOpen(true);
      if (map) {
        map.easeTo({ center: [detailed.lng, detailed.lat], duration: 400 });
        map.setZoom(16);
      }
    } catch {
      toast.error("Não foi possível confirmar este local.");
    } finally {
      setPickupSearching(false);
    }
    setPickupSuggestions([]);
    setPickupMode(false);
  };

  const useGpsPickup = () => {
    setPickupLocation(null);
    setPickupQuery("");
    setPickupDetailsOpen(false);
    setPickupMode(false);
    if (map && coords) {
      map.easeTo({ center: [coords.lng, coords.lat], duration: 400 });
      map.setZoom(15);
    } else requestLocation();
  };

  const recenter = () => {
    if (map && coords) {
      map.easeTo({ center: [coords.lng, coords.lat], duration: 400 });
      map.setZoom(15);
    } else requestLocation();
  };

  const locatePickup = () => {
    if (pickupLocation && map) {
      map.easeTo({ center: [pickupLocation.lng, pickupLocation.lat], zoom: 16, duration: 500 });
    } else {
      recenter();
    }
  };

  const startRequest = async () => {
    if (!user) {
      setAuthOpen(true);
      toast("Entre para continuar com a solicitação.");
      return;
    }
    if (!selectedAddress) {
      toast.error("Escolha um destino primeiro.");
      return;
    }
    const pickup = pickupLocation ?? coords;
    if (!pickup) {
      toast.error("Escolha o local de embarque antes de continuar.");
      return;
    }
    if (!routeInfo) {
      toast.error("Aguarde o trajeto aparecer no mapa antes de continuar.");
      return;
    }
    setRequestState("saving");
    try {
      const distanceKm = routeInfo.distanceMeters / 1000;
      const estimatedFare = Number((PRICING.baseFare + distanceKm * PRICING.perKm).toFixed(2));
      const id = await createRideRequest({
        passengerId: user.uid,
        pickup: { address: pickupLocation?.shortLabel || locationLabel, number: pickupHouseNumber, complement: pickupComplement, lat: pickup.lat, lng: pickup.lng },
        destination: { address: selectedAddress.shortLabel, number: houseNumber, complement, lat: selectedAddress.lat, lng: selectedAddress.lng },
        distanceMeters: routeInfo.distanceMeters,
        durationSeconds: routeInfo.durationSeconds,
        estimatedFare,
      });
      setRideId(id);
      setRequestState("searching");
      toast.success("Solicitação criada. Procurando motorista.");
    } catch (error) {
      console.error(error);
      setRequestState("idle");
      toast.error("Não foi possível solicitar agora. Verifique as regras do Firestore.");
    }
  };

  const cancelActiveRide = async () => {
    if (!rideId || !user) return;
    setCancelling(true);
    try {
      await cancelRideRequest(rideId, user.uid);
      setRequestState("idle");
      setRideId(null);
      setActiveRide(null);
      toast.success("Corrida cancelada.");
    } catch {
      toast.error("Não foi possível cancelar agora.");
    } finally {
      setCancelling(false);
    }
  };

  const activeRideStatus = String(activeRide?.status ?? "searching_driver");
  const activeRideLabel: Record<string, string> = {
    searching_driver: "Procurando motorista",
    driver_assigned: "Motorista encontrado",
    driver_arriving: "Motorista a caminho",
    driver_started: "Corrida em andamento",
    completed: "Corrida finalizada",
  };

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#f4f7f6] text-slate-950">
      <header className="relative z-20 border-b border-white/70 bg-white/75 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between px-4 py-4 sm:px-8 lg:px-12">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-950 text-white shadow-lg shadow-slate-900/15"><Navigation className="h-5 w-5 fill-emerald-400 text-emerald-400" /></div>
            <div><p className="font-display text-xl font-black tracking-tight">vai<span className="text-emerald-600">.go</span></p><p className="text-[10px] font-bold uppercase tracking-[0.24em] text-slate-400">passageiro 2.0</p></div>
          </div>
          <div className="flex items-center gap-2">
            {user ? <><div className="hidden text-right sm:block"><p className="text-sm font-bold text-slate-900">{user.displayName || user.email?.split("@")[0]}</p><p className="text-xs text-slate-400">Conta conectada</p></div><Button variant="outline" size="icon" className="rounded-xl border-slate-200" onClick={() => void firebaseAuth.signOut()} aria-label="Sair"><LogOut className="h-4 w-4" /></Button></> : <Button className="rounded-xl bg-slate-950 px-4 text-white hover:bg-slate-800" onClick={() => setAuthOpen(true)}><UserRound className="mr-2 h-4 w-4" />Entrar</Button>}
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-3xl px-4 py-8 sm:px-8 sm:py-12">
        <div className="mb-7 text-center"><h1 className="font-display text-[clamp(2.4rem,7vw,4.7rem)] font-black leading-[0.95] tracking-[-0.07em] text-slate-950">Para onde você <span className="text-emerald-600">vai?</span></h1></div>

        <Card className="overflow-visible border-white/80 bg-white/90 shadow-2xl shadow-slate-900/10 backdrop-blur-xl">
          <CardContent className="p-3 sm:p-5">
            <div className="rounded-2xl bg-slate-50 p-2.5 sm:p-4">
              <div className="flex items-center gap-2.5"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-emerald-100 text-emerald-700"><Crosshair className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">Local de embarque</p><p className="mt-0.5 break-words text-sm font-bold leading-5 text-slate-800">{pickupLocation?.shortLabel || locationLabel}</p></div><div className="flex shrink-0 items-center gap-0.5"><Button variant="ghost" size="icon" className="h-8 w-8 text-emerald-700 hover:bg-emerald-100" onClick={locatePickup} aria-label="Localizar embarque" title="Localizar embarque"><LocateFixed className="h-4 w-4" /></Button><Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:bg-emerald-100 hover:text-emerald-700" onClick={() => setPickupMode(!pickupMode)} aria-label="Alterar embarque" title="Alterar embarque"><Pencil className="h-4 w-4" /></Button></div></div>
              {pickupMode ? <div className="relative mt-3"><Input autoFocus value={pickupQuery} onChange={(event) => setPickupQuery(event.target.value)} placeholder="Digite a rua do embarque" className="h-11 border-emerald-200 bg-white pr-10" />{pickupSearching ? <Loader2 className="absolute right-3 top-3 h-4 w-4 animate-spin text-emerald-600" /> : null}{pickupSuggestions.length > 0 ? <div className="absolute left-0 right-0 top-12 z-40 divide-y divide-slate-100 overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-2xl">{pickupSuggestions.map((suggestion) => <button key={suggestion.id} onClick={() => selectPickupSuggestion(suggestion)} className="flex w-full items-start gap-3 px-4 py-3 text-left hover:bg-emerald-50"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /><span className="min-w-0"><span className="block truncate text-sm font-bold text-slate-800">{suggestion.shortLabel}</span><span className="mt-1 block truncate text-xs text-slate-400">local alternativo próximo</span></span></button>)}</div> : null}<button className="mt-2 text-xs font-bold text-emerald-700" onClick={useGpsPickup}>Usar minha localização GPS</button></div> : null}
              {pickupDetailsOpen ? <div className="mt-2 grid grid-cols-[0.72fr_1.28fr] gap-1.5"><Input value={pickupHouseNumber} onChange={(event) => setPickupHouseNumber(event.target.value)} placeholder="Nº (opc.)" aria-label="Número do embarque opcional" className="h-9 border-emerald-100 bg-white px-3 text-xs" /><Input value={pickupComplement} onChange={(event) => setPickupComplement(event.target.value)} placeholder="Complemento (opc.)" aria-label="Complemento do embarque opcional" className="h-9 border-emerald-100 bg-white px-3 text-xs" /></div> : null}
            </div>
            <div className="my-3 flex items-center gap-3 px-2"><div className="ml-5 h-6 border-l border-dashed border-slate-300" /><div className="h-px flex-1 bg-slate-100" /></div>
            <div className="relative flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm focus-within:border-emerald-400 focus-within:ring-4 focus-within:ring-emerald-500/10"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-slate-950 text-emerald-300"><MapPin className="h-4 w-4" /></div><div className="min-w-0 flex-1"><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">Destino</p><input value={query} onChange={(event) => { setQuery(event.target.value); setSelectedAddress(null); setDestinationDetailsOpen(false); }} placeholder="Digite: Rua Alf..." className="w-full bg-transparent text-sm font-bold text-slate-900 outline-none placeholder:font-normal placeholder:text-slate-400" aria-label="Buscar destino" />{searching ? <Loader2 className="absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-emerald-600" /> : null}</div></div>
            {suggestions.length > 0 ? <div className="relative z-30 mt-2 divide-y divide-slate-100 overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-xl">{suggestions.map((suggestion) => <button key={suggestion.id} onClick={() => selectSuggestion(suggestion)} className="flex w-full items-start gap-3 px-4 py-3 text-left transition hover:bg-emerald-50"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /><span className="min-w-0"><span className="block truncate text-sm font-bold text-slate-800">{suggestion.shortLabel}</span><span className="mt-1 block truncate text-xs text-slate-400">rua próxima · até 100 km</span></span></button>)}</div> : null}
            {selectedAddress ? <div className="mt-3 rounded-2xl border border-emerald-100 bg-emerald-50/80 p-3"><div className="flex items-center justify-between gap-2"><div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.15em] text-emerald-700"><ShieldCheck className="h-4 w-4" />Destino selecionado</div><Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setSelectedAddress(null); setQuery(""); setHouseNumber(""); setComplement(""); setDestinationDetailsOpen(false); }} aria-label="Limpar destino"><X className="h-4 w-4" /></Button></div><p className="mt-1 text-sm font-bold text-slate-800">{selectedAddress.shortLabel}</p></div> : null}
            {selectedAddress ? (destinationDetailsOpen ? <div className="mt-2 grid grid-cols-[0.72fr_1.28fr] gap-1.5"><Input value={houseNumber} onChange={(event) => setHouseNumber(event.target.value)} placeholder="Nº (opc.)" aria-label="Número do destino opcional" className="h-9 border-slate-200 bg-white px-3 text-xs" /><Input value={complement} onChange={(event) => setComplement(event.target.value)} placeholder="Complemento (opc.)" aria-label="Complemento do destino opcional" className="h-9 border-slate-200 bg-white px-3 text-xs" /></div> : <button type="button" className="mt-2 text-[11px] font-bold text-emerald-700 hover:text-emerald-900" onClick={() => setDestinationDetailsOpen(true)}>Adicionar número ou complemento</button>) : null}

            <div className="relative mt-4 h-[300px] overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 sm:h-[380px]"><MapboxMap center={pickupLocation ?? center} zoom={coords ? 15 : 11} userPosition={pickupLocation ?? coords} destination={selectedAddress} onMapReady={setMap} onRouteInfo={setRouteInfo} className="absolute inset-0 min-h-0" /><div className="pointer-events-none absolute left-3 right-3 top-3 flex items-start justify-between gap-3"><div className="rounded-xl border border-white/70 bg-white/90 px-3 py-2 shadow-lg backdrop-blur"><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Confira no mapa</p><p className="text-xs font-bold text-slate-800">Embarque e destino</p></div><Button variant="outline" size="icon" className="pointer-events-auto rounded-xl border-white/80 bg-white/90 shadow-lg" onClick={locatePickup} aria-label="Localizar embarque"><LocateFixed className="h-4 w-4" /></Button></div></div>
            {routeInfo ? <div className="mt-3 grid grid-cols-3 gap-2"><div className="rounded-2xl bg-slate-50 px-3 py-3"><p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Pela rua</p><p className="mt-1 text-lg font-black text-slate-900">{(routeInfo.distanceMeters / 1000).toFixed(1).replace(".", ",")} km</p></div><div className="rounded-2xl bg-slate-50 px-3 py-3"><p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Tempo</p><p className="mt-1 text-lg font-black text-slate-900">{Math.max(1, Math.round(routeInfo.durationSeconds / 60))} min</p></div><div className="rounded-2xl bg-emerald-50 px-3 py-3"><p className="text-[10px] font-bold uppercase tracking-[0.12em] text-emerald-700">Estimativa</p><p className="mt-1 text-lg font-black text-slate-900">R$ {(PRICING.baseFare + (routeInfo.distanceMeters / 1000) * PRICING.perKm).toFixed(2).replace(".", ",")}</p></div></div> : null}
            {requestState === "searching" ? <div className="mt-4 rounded-2xl border border-emerald-100 bg-emerald-50 p-4"><div className="flex items-center gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-500 text-emerald-950"><Loader2 className="h-5 w-5 animate-spin" /></div><div className="min-w-0 flex-1"><p className="font-bold text-slate-900">{activeRideLabel[activeRideStatus] ?? "Atualizando corrida"}</p><p className="mt-1 text-xs text-slate-600">Sua solicitação está ativa{rideId ? ` · #${rideId.slice(0, 6)}` : ""}.</p></div></div><Button variant="outline" disabled={cancelling} onClick={() => void cancelActiveRide()} className="mt-4 h-10 w-full border-rose-200 text-rose-700 hover:bg-rose-50">{cancelling ? "Cancelando..." : "Cancelar corrida"}</Button></div> : <Button onClick={() => void startRequest()} disabled={requestState === "saving"} className="mt-4 h-12 w-full rounded-2xl bg-emerald-500 font-bold text-emerald-950 shadow-lg shadow-emerald-500/20 hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-50"><Sparkles className="mr-2 h-4 w-4" />{requestState === "saving" ? "Solicitando corrida..." : user ? "Solicitar corrida" : "Entrar para solicitar"}<ArrowRight className="ml-auto h-4 w-4" /></Button>}
          </CardContent>
        </Card>

        <div className="mt-4 flex justify-center text-center text-xs font-semibold text-emerald-700"><span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600" />Confira se o endereço está correto antes de continuar.</span></div>
      </section>
      {authOpen ? <AuthPanel onClose={() => setAuthOpen(false)} /> : null}
    </main>
  );
}
