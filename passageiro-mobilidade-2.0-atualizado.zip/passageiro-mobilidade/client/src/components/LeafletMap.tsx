import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { cn } from "@/lib/utils";

export type LeafletPosition = { lat: number; lng: number };

interface LeafletMapProps {
  className?: string;
  center: LeafletPosition;
  zoom?: number;
  userPosition?: LeafletPosition | null;
  destination?: (LeafletPosition & { label?: string }) | null;
  onMapReady?: (map: L.Map) => void;
}

const userIcon = L.divIcon({
  className: "leaflet-user-icon-wrap",
  html: '<div class="leaflet-user-icon"><span></span></div>',
  iconSize: [34, 34],
  iconAnchor: [17, 17],
});

const destinationIcon = L.divIcon({
  className: "leaflet-destination-icon-wrap",
  html: '<div class="leaflet-destination-icon"><span>●</span></div>',
  iconSize: [32, 38],
  iconAnchor: [16, 36],
});

export function LeafletMap({ className, center, zoom = 12, userPosition, destination, onMapReady }: LeafletMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const destinationMarkerRef = useRef<L.Marker | null>(null);
  const routeRef = useRef<L.Polyline | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, { zoomControl: false, attributionControl: true, preferCanvas: true }).setView([center.lat, center.lng], zoom);
    L.control.zoom({ position: "bottomright" }).addTo(map);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }).addTo(map);
    mapRef.current = map;
    onMapReady?.(map);
    window.setTimeout(() => map.invalidateSize(), 80);
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, [onMapReady]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    map.setView([center.lat, center.lng], Math.max(map.getZoom(), zoom), { animate: true });
  }, [center.lat, center.lng, zoom]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !userPosition) return;
    if (!userMarkerRef.current) userMarkerRef.current = L.marker([userPosition.lat, userPosition.lng], { icon: userIcon, zIndexOffset: 500 }).addTo(map);
    else userMarkerRef.current.setLatLng([userPosition.lat, userPosition.lng]);
  }, [userPosition]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (!destination) {
      destinationMarkerRef.current?.remove();
      destinationMarkerRef.current = null;
      return;
    }
    if (!destinationMarkerRef.current) destinationMarkerRef.current = L.marker([destination.lat, destination.lng], { icon: destinationIcon, zIndexOffset: 700 }).addTo(map);
    else destinationMarkerRef.current.setLatLng([destination.lat, destination.lng]);
    destinationMarkerRef.current.bindTooltip(destination.label ?? "Destino", { direction: "top", offset: [0, -24], opacity: 0.95 });
  }, [destination]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !userPosition || !destination) {
      routeRef.current?.remove();
      routeRef.current = null;
      return;
    }
    const controller = new AbortController();
    const drawRoute = async () => {
      try {
        const url = `https://router.project-osrm.org/route/v1/driving/${userPosition.lng},${userPosition.lat};${destination.lng},${destination.lat}?overview=full&geometries=geojson`;
        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) throw new Error("route_failed");
        const data = await response.json() as { routes?: Array<{ geometry?: { coordinates: Array<[number, number]> } }> };
        const coordinates = data.routes?.[0]?.geometry?.coordinates;
        if (!coordinates?.length) return;
        routeRef.current?.remove();
        routeRef.current = L.polyline(coordinates.map(([lng, lat]) => [lat, lng] as [number, number]), { color: "#00a878", weight: 6, opacity: 0.9, lineCap: "round", lineJoin: "round" }).addTo(map);
        map.fitBounds(routeRef.current.getBounds(), { padding: [42, 42], maxZoom: 16, animate: true });
      } catch (error) {
        if ((error as Error).name !== "AbortError") console.warn("Não foi possível desenhar a rota", error);
      }
    };
    void drawRoute();
    return () => controller.abort();
  }, [destination, userPosition]);

  return <div ref={containerRef} className={cn("h-full min-h-[430px] w-full overflow-hidden", className)} />;
}
