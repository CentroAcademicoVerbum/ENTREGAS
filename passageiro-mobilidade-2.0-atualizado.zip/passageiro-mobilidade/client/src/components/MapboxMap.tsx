import { useEffect, useRef } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { cn } from "@/lib/utils";

export type MapboxPosition = { lat: number; lng: number };

interface MapboxMapProps {
  className?: string;
  center: MapboxPosition;
  zoom?: number;
  userPosition?: MapboxPosition | null;
  destination?: (MapboxPosition & { label?: string }) | null;
  onMapReady?: (map: mapboxgl.Map) => void;
  onRouteInfo?: (info: { distanceMeters: number; durationSeconds: number } | null) => void;
}

const token = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN as string | undefined;
const routeSourceId = "passenger-route";

function markerElement(kind: "user" | "destination") {
  const element = document.createElement("div");
  element.className = `mapbox-marker mapbox-marker-${kind}`;
  element.innerHTML = kind === "user" ? '<span class="mapbox-marker-dot"></span>' : '<span class="mapbox-marker-pin">●</span>';
  return element;
}

export function MapboxMap({ className, center, zoom = 12, userPosition, destination, onMapReady, onRouteInfo }: MapboxMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const userMarkerRef = useRef<mapboxgl.Marker | null>(null);
  const destinationMarkerRef = useRef<mapboxgl.Marker | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current || !token) return;
    mapboxgl.accessToken = token;
    const map = new mapboxgl.Map({
      container: containerRef.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: [center.lng, center.lat],
      zoom,
      attributionControl: true,
      cooperativeGestures: true,
    });
    map.addControl(new mapboxgl.NavigationControl({ showCompass: false }), "bottom-right");
    mapRef.current = map;
    map.on("load", () => onMapReady?.(map));
    return () => {
      userMarkerRef.current?.remove();
      destinationMarkerRef.current?.remove();
      map.remove();
      mapRef.current = null;
    };
  }, [onMapReady]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    map.easeTo({ center: [center.lng, center.lat], zoom: Math.max(map.getZoom(), zoom), duration: 500 });
  }, [center.lat, center.lng, zoom]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !userPosition) return;
    const position: [number, number] = [userPosition.lng, userPosition.lat];
    if (!userMarkerRef.current) userMarkerRef.current = new mapboxgl.Marker({ element: markerElement("user"), anchor: "center" }).setLngLat(position).addTo(map);
    else userMarkerRef.current.setLngLat(position);
  }, [userPosition]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (!destination) {
      destinationMarkerRef.current?.remove();
      destinationMarkerRef.current = null;
      return;
    }
    const position: [number, number] = [destination.lng, destination.lat];
    if (!destinationMarkerRef.current) destinationMarkerRef.current = new mapboxgl.Marker({ element: markerElement("destination"), anchor: "bottom" }).setLngLat(position).addTo(map);
    else destinationMarkerRef.current.setLngLat(position);
    destinationMarkerRef.current.setPopup(new mapboxgl.Popup({ offset: 24, closeButton: false }).setText(destination.label ?? "Destino"));
  }, [destination]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !userPosition || !destination || !token) {
      onRouteInfo?.(null);
      if (map?.getLayer(routeSourceId)) map.removeLayer(routeSourceId);
      if (map?.getSource(routeSourceId)) map.removeSource(routeSourceId);
      return;
    }
    const controller = new AbortController();
    const drawRoute = async () => {
      try {
        const coordinates = `${userPosition.lng},${userPosition.lat};${destination.lng},${destination.lat}`;
        const url = `https://api.mapbox.com/directions/v5/mapbox/driving/${coordinates}.json?overview=full&geometries=geojson&access_token=${encodeURIComponent(token)}`;
        const response = await fetch(url, { signal: controller.signal });
        if (!response.ok) throw new Error("route_failed");
        const data = await response.json() as { routes?: Array<{ geometry?: GeoJSON.LineString; distance?: number; duration?: number }> };
        const route = data.routes?.[0];
        const geometry = route?.geometry;
        if (!geometry || controller.signal.aborted) return;
        if (typeof route.distance === "number" && typeof route.duration === "number") onRouteInfo?.({ distanceMeters: route.distance, durationSeconds: route.duration });
        const paint = { "line-color": "#00a878", "line-width": 6, "line-opacity": 0.9 };
        const source = map.getSource(routeSourceId) as mapboxgl.GeoJSONSource | undefined;
        if (source) source.setData({ type: "Feature", properties: {}, geometry });
        else {
          map.addSource(routeSourceId, { type: "geojson", data: { type: "Feature", properties: {}, geometry } });
          map.addLayer({ id: routeSourceId, type: "line", source: routeSourceId, layout: { "line-cap": "round", "line-join": "round" }, paint });
        }
        const bounds = new mapboxgl.LngLatBounds();
        geometry.coordinates.forEach(([lng, lat]) => bounds.extend([lng, lat]));
        map.fitBounds(bounds, { padding: 52, maxZoom: 16, duration: 600 });
      } catch (error) {
        if ((error as Error).name !== "AbortError") console.warn("Não foi possível desenhar a rota Mapbox", error);
      }
    };
    if (map.isStyleLoaded()) void drawRoute();
    else map.once("load", drawRoute);
    return () => {
      controller.abort();
      map.off("load", drawRoute);
    };
  }, [destination, userPosition, onRouteInfo]);

  if (!token) return <div className={cn("grid h-full min-h-[430px] place-items-center bg-slate-100 p-6 text-center text-sm text-slate-500", className)}>Configure o token público do Mapbox para carregar o mapa.</div>;
  return <div ref={containerRef} className={cn("h-full min-h-[430px] w-full overflow-hidden", className)} />;
}
