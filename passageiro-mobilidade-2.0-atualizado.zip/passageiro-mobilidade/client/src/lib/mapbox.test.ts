import { describe, expect, it } from "vitest";

describe("Mapbox credentials", () => {
  it("accepts the configured public token", async () => {
    const token = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN as string | undefined;
    expect(token).toMatch(/^pk\./);

    const response = await fetch(`https://api.mapbox.com/styles/v1/mapbox/streets-v12?access_token=${encodeURIComponent(token ?? "")}`, { headers: { Origin: "https://passageiro-txfu7c8q.manus.space" } });
    const body = await response.text();
    expect(response.ok, `Mapbox returned ${response.status}: ${body.slice(0, 240)}`).toBe(true);
  }, 15000);
});
