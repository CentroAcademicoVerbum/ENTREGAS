import { getApp, getApps, initializeApp } from "firebase/app";
import {
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  type User,
} from "firebase/auth";
import { addDoc, collection, doc, getFirestore, onSnapshot, serverTimestamp, updateDoc, type Unsubscribe } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBKxSTEisEteLVeh7fJRz4oC8K4dc7oSP0",
  authDomain: "projectuber2-e40d8.firebaseapp.com",
  projectId: "projectuber2-e40d8",
  storageBucket: "projectuber2-e40d8.firebasestorage.app",
  messagingSenderId: "894307316297",
  appId: "1:894307316297:web:87488f93a2cc8bf829c598",
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });

export const firebaseAuth = {
  signInEmail: (email: string, password: string) =>
    signInWithEmailAndPassword(auth, email, password),
  createEmail: (email: string, password: string) =>
    createUserWithEmailAndPassword(auth, email, password),
  signInGoogle: () => signInWithPopup(auth, googleProvider),
  signOut: () => signOut(auth),
  observe: (callback: (user: User | null) => void) =>
    onAuthStateChanged(auth, callback),
};

export async function createRideRequest(input: {
  passengerId: string;
  pickup: { address: string; number: string; complement: string; lat: number; lng: number };
  destination: { address: string; number: string; complement: string; lat: number; lng: number };
  distanceMeters: number;
  durationSeconds: number;
  estimatedFare: number;
}) {
  const reference = await addDoc(collection(db, "rides"), {
    ...input,
    status: "searching_driver",
    driverId: null,
    createdAt: serverTimestamp(),
  });
  return reference.id;
}

export function observeRide(rideId: string, callback: (ride: Record<string, unknown> | null) => void, onError?: (error: Error) => void): Unsubscribe {
  return onSnapshot(doc(db, "rides", rideId), (snapshot) => {
    callback(snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null);
  }, (error) => onError?.(error));
}

export async function cancelRideRequest(rideId: string, passengerId: string) {
  await updateDoc(doc(db, "rides", rideId), {
    status: "cancelled",
    cancelledBy: "passenger",
    cancelledAt: serverTimestamp(),
    cancelledByUserId: passengerId,
  });
}

export function friendlyAuthError(error: unknown) {
  const code = (error as { code?: string })?.code ?? "";
  const messages: Record<string, string> = {
    "auth/invalid-credential": "E-mail ou senha incorretos.",
    "auth/invalid-email": "Digite um e-mail válido.",
    "auth/email-already-in-use": "Este e-mail já está cadastrado.",
    "auth/weak-password": "Use uma senha com pelo menos 6 caracteres.",
    "auth/popup-closed-by-user": "A janela de login foi fechada.",
    "auth/popup-blocked": "O navegador bloqueou a janela de login.",
    "auth/too-many-requests": "Muitas tentativas. Aguarde alguns instantes.",
  };
  return messages[code] ?? "Não foi possível concluir o login agora.";
}
