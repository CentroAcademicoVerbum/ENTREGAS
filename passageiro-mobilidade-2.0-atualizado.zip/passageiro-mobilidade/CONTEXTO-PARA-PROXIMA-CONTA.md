# Contexto técnico — Passageiro Mobilidade 2.0

## Objetivo do projeto

Este projeto é o painel web do passageiro de um protótipo de mobilidade chamado **vai.go / Passageiro 2.0**. A intenção é evoluir depois para Android usando Capacitor. O projeto deve permanecer sem Cloud Functions e priorizar serviços gratuitos ou com cotas gratuitas.

## Projeto e execução

- Diretório: `/home/ubuntu/passageiro-mobilidade`
- Stack: React 19, TypeScript, Vite, Tailwind 4, shadcn/ui, Mapbox GL JS, Firebase SDK.
- Servidor de desenvolvimento: `pnpm dev`
- Checagem de tipos: `pnpm check`
- Build de produção: `pnpm build`
- Preview atual: `https://3000-iwg6mtdxjzxbmp1mgnor6-66df69a7.us1.manus.computer`
- Domínio publicado: `https://passageiro-txfu7c8q.manus.space`

## Estado funcional atual

### Mapa e endereços

- O mapa usa **Mapbox GL JS** em `client/src/components/MapboxMap.tsx`.
- A busca/autocomplete usa Mapbox Search Box/Geocoding com proximidade e sessão de busca.
- A rota usa Mapbox Directions API, retornando distância em metros e duração em segundos.
- A interface mostra distância real pela rua, duração estimada e valor final.
- O botão de localizar centraliza o mapa no embarque atual ou no embarque alternativo.
- Endereço completo não deve ser truncado nem abreviado visualmente.

### Firebase

- Configuração client-side em `client/src/lib/firebase.ts`.
- Firebase Authentication por e-mail/senha e Google já está preparado.
- Cloud Firestore é a escolha oficial para corridas e status em tempo real.
- Não usar Cloud Functions nesta arquitetura.
- A coleção usada é `rides`.
- Criação: `createRideRequest()` grava origem, destino, coordenadas, distância, duração, tarifa, `passengerId`, `status: searching_driver` e `createdAt`.
- Monitoramento: `observeRide(rideId, callback)` usa `onSnapshot` em `rides/{rideId}`.
- Cancelamento: `cancelRideRequest()` usa `updateDoc` e grava `status: cancelled`, `cancelledBy: passenger`, `cancelledAt` e `cancelledByUserId`.

## Fluxo do passageiro

1. Usuário escolhe o local de embarque por localização ou pelo botão Alterar.
2. Usuário busca e seleciona o destino.
3. Número e complemento ficam ocultos por padrão e aparecem somente depois da seleção do endereço.
4. O mapa desenha a rota real.
5. O resumo mostra distância, tempo e valor final.
6. O usuário precisa estar autenticado para solicitar.
7. Ao solicitar, o app grava a corrida no Firestore e mostra a tela de corrida ativa.
8. O status acompanhado pelo Firestore pode ser:
   - `searching_driver`: Procurando motorista
   - `driver_assigned`: Motorista encontrado
   - `driver_arriving`: Motorista a caminho
   - `driver_started`: Corrida em andamento
   - `completed`: Corrida finalizada
   - `cancelled`: Corrida cancelada
9. O passageiro pode cancelar enquanto a corrida ativa estiver sendo exibida.

## Tarifa atual

A tarifa está centralizada em `client/src/pages/Home.tsx`:

```ts
const PRICING = {
  baseFare: 5,
  perKm: 2.2,
} as const;
```

O cálculo é `baseFare + distância real em km * perKm`. O usuário vê somente o valor final; a fórmula não aparece na interface.

## Ajuste recente do botão de solicitação

O botão havia ficado silenciosamente desabilitado por causa de `disabled={!routeInfo}`. Isso foi corrigido: agora ele fica clicável, exceto durante o salvamento. Se faltar embarque ou rota real, `startRequest()` mostra uma mensagem clara:

- Sem embarque: `Escolha o local de embarque antes de continuar.`
- Sem rota: `Aguarde o trajeto aparecer no mapa antes de continuar.`

O texto técnico `Salvando solicitação...` foi trocado por `Solicitando corrida...`.

## Interface atual

- Cabeçalho limpo: apenas `Para onde você vai?`
- Removidos textos técnicos como GPS ativo, coordenadas e GPS pendente.
- Cartão de embarque compacto.
- No mobile, Localizar e Alterar são botões apenas com ícones, com `aria-label` e `title`.
- Destino aparece abaixo do embarque.
- Mapa fica abaixo dos campos.
- A orientação verde fica abaixo do botão: `Confira se o endereço está correto antes de continuar.`

## Problemas/pendências importantes

1. **Regras do Firestore ainda precisam ser configuradas.** Sem regras que permitam ao passageiro autenticado criar e ler somente suas próprias corridas, a criação ou o listener podem retornar `permission-denied`.
2. Criar o painel do motorista para consultar corridas `searching_driver` e aceitar uma corrida.
3. Criar regras de concorrência para impedir dois motoristas de aceitarem a mesma corrida.
4. Adicionar leitura filtrada das corridas do passageiro por `passengerId`.
5. Implementar atualização de localização do motorista no app do motorista.
6. Validar o fluxo em dispositivo Android real depois da adaptação com Capacitor.
7. O token Mapbox é público (`pk...`) e deve permanecer protegido por restrições de URL no painel Mapbox. No WebDev, ele foi configurado como segredo/variável do projeto.

## Recomendação de regras iniciais do Firestore

Não aplicar cegamente em produção; revisar quando o painel do motorista existir. A regra deve garantir autenticação, ownership do passageiro e mudanças de status controladas. Nunca liberar `allow read, write: if true`.

## Arquivos principais

- `client/src/pages/Home.tsx`: tela e fluxo completo do passageiro.
- `client/src/components/MapboxMap.tsx`: mapa, marcadores e Directions API.
- `client/src/lib/firebase.ts`: Auth, Firestore, criação, listener e cancelamento da corrida.
- `client/src/index.css`: identidade visual e estilos globais.
- `package.json`: dependências e scripts.

## Verificação realizada

Executados com sucesso:

```bash
pnpm check
pnpm build
```

O build gera `dist/public` e `dist/index.js`. Existe apenas o aviso do Vite sobre o bundle JavaScript principal acima de 500 kB; não é erro de compilação.

## Próxima tarefa recomendada

Começar pelo painel do motorista, mantendo o Firestore como fonte única:

1. consulta de corridas abertas;
2. card com origem, destino, distância e valor;
3. aceite transacional/seguro;
4. atualização de `driverId` e `status`;
5. passageiro recebendo a mudança via `onSnapshot`.

Não migrar para Realtime Database neste momento. Usar Firestore para manter o modelo de corrida, histórico e status em um único lugar.

## Observação sobre o ZIP

O arquivo ZIP que acompanha este contexto deve conter o código-fonte, `dist` compilado, `package.json`, lockfile, configurações e este documento. Não incluir `node_modules`, caches ou credenciais privadas.

Última correção empacotada: botão de solicitação não fica mais bloqueado silenciosamente quando a rota ainda está carregando.
